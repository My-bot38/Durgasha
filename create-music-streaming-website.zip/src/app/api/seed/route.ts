import { db } from "@/db";
import { playlists, songs, credits } from "@/db/schema";
import { getSettings } from "@/db/queries";

export const dynamic = "force-dynamic";

const DURGA_SONGS = [
  { title: "Dugga Elo", artist: "Monali Thakur", duration: "2:27" },
  {
    title: "Dugga Ma (Original Motion Picture Soundtrack)",
    artist: "Arijit Singh",
    duration: "4:31",
  },
  {
    title: "Ebar Jeno Onno Rokom Pujo",
    artist: "Nakash Aziz Official",
    duration: "3:33",
  },
  {
    title: "Dhak Baja Kashor Baja",
    artist: "Shreya Ghoshal Official",
    duration: "4:26",
  },
  { title: "Bolo Dugga Elo", artist: "Kaushik-Guddu", duration: "3:20" },
  { title: "Aamaar Dugga", artist: "Monali Thakur", duration: "3:20" },
  {
    title: "Dhaker Taley (Original Motion Picture Soundtrack)",
    artist: "Release",
    duration: "4:43",
  },
  { title: "Dugga Elo", artist: "Akriti Kakar", duration: "3:58" },
  { title: "Shundori Komola", artist: "Release", duration: "3:14" },
  { title: "Elo Je Maa", artist: "Abhijeet Unplugged", duration: "5:08" },
];

const MAHALAYA_SONGS = [
  { title: "Jago Tumi Jago", artist: "Traditional", duration: "6:12" },
  { title: "Mahishasura Mardini", artist: "Birendra Krishna Bhadra", duration: "8:45" },
  { title: "Ya Chandi", artist: "Traditional", duration: "5:30" },
];

export async function POST() {
  await getSettings();

  const existing = await db.select().from(playlists);
  if (existing.length > 0) {
    return Response.json({ ok: true, message: "Already seeded" });
  }

  const [durga] = await db
    .insert(playlists)
    .values({
      name: "DURGA PUJA",
      description: "The main curated Durga Puja playlist.",
      sortOrder: 1,
    })
    .returning();

  const [mahalaya] = await db
    .insert(playlists)
    .values({
      name: "MAHALAYA",
      description: "Mahalaya morning collection.",
      sortOrder: 2,
    })
    .returning();

  await db
    .insert(playlists)
    .values({
      name: "MAHALAYA SONGS",
      description: "Devotional Mahalaya songs.",
      sortOrder: 3,
    });

  await db.insert(songs).values(
    DURGA_SONGS.map((s, i) => ({
      playlistId: durga.id,
      title: s.title,
      artist: s.artist,
      duration: s.duration,
      audioUrl: "",
      coverUrl: "",
      sortOrder: i + 1,
    }))
  );

  await db.insert(songs).values(
    MAHALAYA_SONGS.map((s, i) => ({
      playlistId: mahalaya.id,
      title: s.title,
      artist: s.artist,
      duration: s.duration,
      audioUrl: "",
      coverUrl: "",
      sortOrder: i + 1,
    }))
  );

  await db.insert(credits).values([
    {
      name: "Ritam Biswas",
      photoUrl: "",
      linkedinUrl: "#",
      instagramUrl: "#",
      sortOrder: 1,
    },
    {
      name: "Arup Matabber",
      photoUrl: "",
      linkedinUrl: "#",
      instagramUrl: "#",
      sortOrder: 2,
    },
  ]);

  return Response.json({ ok: true, message: "Seeded" });
}
